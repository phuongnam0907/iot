package com.example.phuongnam0907.gatwayiot;

/**
 * Created by Le Trong Nhan on 19/06/2018.
 */

public class NPNConstants {
    public static final String apiHeaderKey = "User-Agent";
    public static final String apiHeaderValue = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36 NPNLab";

}
