package com.example.phuongnam0907.gatwayiot.MVVM.View;

/**
 * Created by Le Trong Nhan on 19/06/2018.
 */

public interface NPNHomeView extends IView {
    void onSuccessUpdateServer(String message);
    void onErrorUpdateServer(String message);
}
